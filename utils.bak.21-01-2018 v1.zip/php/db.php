<?php


class db
{

  function connect ()
  {
    if (!$link = mysqli_connect("127.0.0.1", "root", "", "johnny")) {
        echo 'Could not connect to mysql';
        exit;
    }

    if (!mysqli_select_db($link,"johnny")) {
        echo 'Could not select database';
        exit;
    }
  }

  function get () {
    $link = mysqli_connect("127.0.0.1", "root", "", "johnny");
    $sql="SELECT id, project, steps, expected, createdby FROM users ORDER BY id";
    $result=mysqli_query($link,$sql);
    while ($row = mysqli_fetch_assoc($result))
   {  echo '
       <tr>
         <th  scope="row">' ; echo $row['id'] ; echo '</th>
         <td style="width: 180px">' ; echo $row['project'] ; echo'</td>
         <td>' ; echo $row['steps'] ; echo'</td>
         <td>' ; echo $row['expected'] ; echo'</td>
         <td>' ; echo $row['createdby'] ; echo'</td>';
      echo '</tr>';
   }
      // Fetch one and one row


      // Free result set
      // return mysqli_free_result($result);
    }
    function close () {
      $link = mysqli_connect("127.0.0.1", "root", "", "johnny");
      mysqli_close($link);
    }
  }








// if ($result=mysqli_query($link,$sql))
//   {
//   // Fetch one and one row
//   while ($row=mysqli_fetch_row($result))
//     {
//     printf ("%s (%s)\n",$row[0],$row[1]);
//     }
//   // Free result set
//   mysqli_free_result($result);
// }

mysqli_close($link);
?>
