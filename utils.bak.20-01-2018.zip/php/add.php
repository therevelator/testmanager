<?php
class Table {

function addHeader() {
  echo "<br><br><br>";
  echo '
<div align="center">
  <table class="dc_table_s10" summary="Sample Table" style="width:80%;">
    <thead>
        <tr>
          <th style="width: 80px" scope="col">ID</th>
          <th style="width: 80px" scope="col">Project</th>
          <th style="width: 320px" scope="col">Steps</th>
          <th scope="col">Expected Result</th>
          <th scope="col">Created By</th>
          <th style="width: 280px;" scope="col">Action</th>
        </tr>
      </thead>
    <tbody>
  </div>';
}

function add($id = NULL, $project = NULL, $steps = NULL, $expected = NULL, $created = NULL) {
  echo '
      <tr>
        <th scope="row">' ; echo $id ; echo '</th>
        <td>' ; echo $project ; echo'</td>
        <td>' ; echo $steps ; echo'</td>
        <td>' ; echo $expected ; echo'</td>
        <td>' ; echo $created ; echo'</td>';

}

function buttons () {
  echo '<td><input class="dc_3d_button green" type="submit" name="Add"  value="Add">
  <input class="dc_3d_button orange" type="submit" name="Edit"  value="Edit">
  <input class="dc_3d_button red" type="submit" name="Add"  value="Delete"></td>
  </tr>';
}
function endTable() {
  echo '</tbody>
</table>
</div>
';
}

}



?>
