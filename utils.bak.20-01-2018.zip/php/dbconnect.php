 <?php
  $host="localhost";
  $uname="johnny";
  $pass="";

  $connection= mysqli_connect ($host, $uname, $pass);
  if (! $connection) {
    die ("A connection to the Server could not be established!");
  } else {
    echo "User root logged into to MySQL server ",$host," successfully.";
  }
  ?>
  
