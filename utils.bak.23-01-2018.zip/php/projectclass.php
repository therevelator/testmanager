<?php

/**This class is aimed at controlling the views of the entire system.
 * It renders the table structure and provides placeholders, eventually :)
 */
//db connect for the global purpose
 if (!$link = mysqli_connect("127.0.0.1", "root", "", "johnny")) {
     echo 'Could not connect to mysql';
     exit;
 }

 if (!mysqli_select_db($link,"johnny")) {
     echo 'Could not select database';
     exit;
}

class view
{

  function viewProjects ()
  {
    $link = mysqli_connect("127.0.0.1", "root", "", "johnny");
    $sql="SELECT ProjectID, ProjectName, createdby FROM project ORDER BY ProjectID DESC";
    $result=mysqli_query($link,$sql);
    if (!$result) {
    printf("Error: %s\n", mysqli_error($link));
    exit();
}
    function addProject () {
    echo '
    <div align="center">
      <table class="dc_tables2_0" cellspacing="0" summary="DT features" style="width:60%;">
      <tr>
        <th>Projects</th>
        <th>Created By</th>
        <th>Details</th>
      </tr>';
      var_dump($_POST);
    while ($row = mysqli_fetch_assoc($result))
    // Fetch one and one row

    {$projectid = $row['ProjectID'] = $_SESSION['ProjectID'];
     echo '<tr>
       <td><input id="example1div" type="text" name="Project Name"></td>
       <td>' ; echo $row['createdby'] ; echo'</td>
       <td>' ; echo $row['ProjectID'] ; echo'</td>
     </tr>';
     echo '<input class="dc_3d_button red" type="submit" name="Delete" value="'; echo $projectid; echo '">';
    }
    echo '<td><input class="dc_3d_button orange" type="submit" name="Done" value="Done">
      <input class="dc_3d_button red" type="submit" name="Add"  value="Save"></td>';
    echo "<br><br><br>";
  }
}
}





?>
