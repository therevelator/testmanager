<?php

/**This class is aimed at controlling the views of the entire system.
 * It renders the table structure and provides placeholders, eventually :)
 */
//db connect for the global purpose
 if (!$link = mysqli_connect("127.0.0.1", "root", "", "johnny")) {
     echo 'Could not connect to mysql';
     exit;
 }

 if (!mysqli_select_db($link,"johnny")) {
     echo 'Could not select database';
     exit;
}

class view
{

  function addHeader() {
    echo "<br><br><br>";
    echo '
  <div align="center">
    <table class="dc_table_s7" summary="Project Table" style="width:60%;">
      <thead>
          <tr>
            <th style="width: 80px" scope="col">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ID</th>
            <th style="width: 320px" scope="col">Project Name</th>
            <th scope="col">Created By</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
      <tbody>
    </div>';
  }

  function viewProjects ()
  {
      $link = mysqli_connect("127.0.0.1", "root", "", "johnny");
      $sql="SELECT ProjectID, ProjectName, CreatedBy FROM project ORDER BY ProjectID";
      $result=mysqli_query($link,$sql);
      while ($row = mysqli_fetch_assoc($result))
      // Fetch one and one row
     { $ID = $row['ProjectID'];
       echo '
         <tr>
           <td  scope="row"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' . $ID .  '</td>
           <td>' ; echo $row['ProjectName'] ; echo'</td>
           <td>' ; echo $row['CreatedBy'] ; echo'</td>
           <td><input class="dc_3d_button red" type="submit" name="Delete" value="'; echo $ID; echo '">
           <input  type="hidden" id="Delete" value="Delete '; echo $row['id']; echo '"></td>
          </tr>';

     }
  }


    // echo "<br><br><br>";
//add the Edit Project function
    function addProject () {
      echo '
      <tr>
        <th scope="row">' ; echo @$id ; echo '</th>
        <td><input id="example1div" type="text" name="Project Name"></td>
        <td>' ; echo @$created ; echo'</td>';
        echo '<td><input class="dc_3d_button orange" type="submit" name="Done" value="Done">
        <input class="dc_3d_button red" type="submit" name="Add"  value="Save"></td><tr>';
    }

    function writeProject ($projectName) {
      $user = $_SESSION['username'];
      $projectName = $_POST['Project_Name'];
      $link = mysqli_connect("127.0.0.1", "root", "", "johnny");
      $sql="INSERT INTO project (ProjectName, CreatedBy) VALUES ('$projectName', '$user')";
      $result=mysqli_query($link,$sql);
      if (!$result) {
      printf("Error: %s\n", mysqli_error($link));
      exit();
      // $link = mysqli_connect("127.0.0.1", "root", "", "johnny");
      

}
}
}
